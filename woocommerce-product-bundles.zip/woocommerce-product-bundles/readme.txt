=== WooCommerce Product Bundles ===

Contributors: SomewhereWarm
Tags: woocommerce, product, bundle, bundles, kits, simple, variable, configurable
Requires at least: 4.4
Tested up to: 6.0
Stable tag: 6.22.4
WC requires at least: 3.9
WC tested up to: 8.2
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Offer product bundles, bulk discount packages, and assembled products.

== Description ==

Create assembled products and product bundles by grouping simple, variable and subscription products.

Looking for help? Read the full documentation [here](http://docs.woocommerce.com/document/bundles/).
